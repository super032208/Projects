import React, { Component } from 'react';

export default class friends extends Component {
  render() {
    return (
      <React.Fragment>
        <h1 id='friends'>Friends</h1>
        <div id='row'>
          <div id='column'>
            <img id='pic1' src='https://unsplash.it//g/300/300' />
            <img id='pic2' src='https://unsplash.it//g/300/300' />
            <img id='pic3' src='https://unsplash.it//g/300/300' />
            <img id='pic2' src='https://unsplash.it//g/300/300' />
          </div>
        </div>
      </React.Fragment>
    );
  }
}
