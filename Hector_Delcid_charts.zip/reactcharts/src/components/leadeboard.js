import React, { Component } from 'react';

export default class leadeboard extends Component {
  render() {
    return (
      <React.Fragment>
        <div id='div-leader'>
          <h1> VP Leaderboard</h1>
          <p>Friend Steps Leaderboard</p>
        </div>

        <table id='table-id'>
          <tr>
            <th>Friends</th>
            <th>Steps</th>
          </tr>
          <tr>
            <td>Mahe lefebvre</td>
            <td>900</td>
          </tr>
          <tr>
            <td>Lya Garcia</td>
            <td>8000</td>
          </tr>
          <tr>
            <td>Eva Walker</td>
            <td>9000</td>
          </tr>
          <tr>
            <td>Josua Winker</td>
            <td>7500</td>
          </tr>
          <tr>
            <td>Mia Cox</td>
            <td>8500</td>
          </tr>
          <tr>
            <td>Noah white</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>Sofia Harris</td>
            <td>100000</td>
          </tr>
        </table>
      </React.Fragment>
    );
  }
}
