import React, { Component } from 'react';

import { Bar, Line, Pie } from 'react-chartjs-2';

class Chart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: {
        labels: [
          'Sunday',
          'Monday',
          'Tuesday',
          'Wednesday',
          'Thursday',
          'Friday',
          'Saturday'
        ],
        datasets: [
          {
            label: '#Steps',
            data: [900, 8000, 9000, 7500, 8800, 5000, 10000, 0],
            //backgroundColor: rgba values
            backgroundColor: [
              'rgba(255, 99, 132, 0.6)',
              'rgba(54, 162, 235, 0.6)',
              'rgba(255, 206, 86, 0.6)',
              'rgba(75, 192, 192, 0.6)',
              'rgba(153, 102, 255, 0.6)',
              'rgba(255, 159, 64, 0.6)',
              'rgba(255, 99, 132, 0.6)'
            ]
          }
        ]
      }
    };
  }

  render() {
    return (
      <div className='chart'>
        <Bar
          data={this.state.chartData}
          options={{
            title: {
              display: true,
              text: 'Welcome to Virgin Pulse!',
              fontSize: 16
            },
            legend: {
              display: true,
              position: 'right'
            }
          }}
        />
      </div>
    );
  }
}

export default Chart;
