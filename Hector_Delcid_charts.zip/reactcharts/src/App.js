import React from 'react';
import logo from './logo.svg';
import './App.css';
import './Style.css';
import Chart from './components/Chart';
import Friends from './components/friends';
import Leaderboard from './components/leadeboard';

function App() {
  return (
    <div className='App'>
      <header className='App-header'>
        <img src='https://www.virginpulse.com/wp-content/uploads/2013/10/VIR-logo-color-340x160-2.jpg' />

        <h1>"Give me a chance... </h1>
        <h2> I promise I won't disappoint you " </h2>
      </header>
      <Chart /> <br />
      <Leaderboard />
      <br />
      <Friends />
    </div>
  );
}

export default App;
